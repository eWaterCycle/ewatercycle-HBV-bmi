# HBV-BMI

Basic Model Interface (BMI) HBV model compatible with [eWaterCycle](https://github.com/eWaterCycle)

HBV uses basic implementation with no snow component yet (v.0.1.4)

Actual eWatercycle model wrapper can be found on [github](https://github.com/Daafip/ewatercycle-hbv)

 


